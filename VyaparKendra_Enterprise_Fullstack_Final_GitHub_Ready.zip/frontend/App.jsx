import { useEffect, useState } from "react";
import axios from "axios";

export default function App(){

  const [status,setStatus] = useState("Loading...");

  useEffect(()=>{
    axios.get("/api/health")
      .then(res=>setStatus(res.data.status))
      .catch(()=>setStatus("Backend Not Connected"));
  },[]);

  return(
    <div style={{padding:40}}>
      <h1>VyaparKendra Enterprise Platform</h1>
      <p>{status}</p>
    </div>
  );
}