import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();
const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI)
  .then(()=>console.log("Mongo Connected"))
  .catch(err=>console.log(err));

app.get("/api/health",(req,res)=>{
  res.json({status:"VyaparKendra Enterprise Running"});
});

app.listen(process.env.PORT || 5000, ()=>{
  console.log("Server Running");
});