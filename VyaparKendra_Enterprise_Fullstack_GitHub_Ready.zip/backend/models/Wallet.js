import mongoose from "mongoose";
export default mongoose.model("Wallet", new mongoose.Schema({
  mitraId:mongoose.Schema.Types.ObjectId,
  balance:{ type:Number, default:0 }
}));