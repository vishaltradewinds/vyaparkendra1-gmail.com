import mongoose from "mongoose";
export default mongoose.model("Ledger", new mongoose.Schema({
  type:String,
  debit:String,
  credit:String,
  amount:Number,
  createdAt:{ type:Date, default:Date.now }
}));