import express from "express";
import Ledger from "../models/Ledger.js";
import Wallet from "../models/Wallet.js";

const router = express.Router();

router.get("/", async (req,res)=>{

  const revenue = await Ledger.aggregate([
    { $match:{ type:"SERVICE_DEBIT" }},
    { $group:{ _id:null, total:{ $sum:"$amount" }}}
  ]);

  const wallet = await Wallet.aggregate([
    { $group:{ _id:null, total:{ $sum:"$balance" }}}
  ]);

  res.json({
    financial:{
      grossRevenue: revenue[0]?.total || 0,
      walletLiability: wallet[0]?.total || 0
    }
  });
});

export default router;