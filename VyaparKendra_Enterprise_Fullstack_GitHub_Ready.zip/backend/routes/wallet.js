import express from "express";
import Wallet from "../models/Wallet.js";
import Ledger from "../models/Ledger.js";

const router = express.Router();

router.post("/recharge", async (req,res)=>{
  const { mitraId, amount } = req.body;

  await Wallet.findOneAndUpdate(
    { mitraId },
    { $inc:{ balance:amount }},
    { upsert:true }
  );

  await Ledger.create({
    type:"RECHARGE",
    debit:"BANK",
    credit:"MITRA_WALLET",
    amount
  });

  res.json("Wallet Credited");
});

export default router;