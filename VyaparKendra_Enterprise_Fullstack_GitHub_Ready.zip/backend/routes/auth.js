import express from "express";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import User from "../models/User.js";

const router = express.Router();

router.post("/register", async (req,res)=>{
  const { name,email,password,role } = req.body;
  const hash = await bcrypt.hash(password,10);
  const user = await User.create({ name,email,password:hash,role });
  res.json(user);
});

router.post("/login", async (req,res)=>{
  const { email,password } = req.body;
  const user = await User.findOne({ email });
  if(!user) return res.status(400).json("User not found");

  const valid = await bcrypt.compare(password,user.password);
  if(!valid) return res.status(400).json("Invalid password");

  const token = jwt.sign({ id:user._id, role:user.role }, process.env.JWT_SECRET);
  res.json({ token, role:user.role });
});

export default router;