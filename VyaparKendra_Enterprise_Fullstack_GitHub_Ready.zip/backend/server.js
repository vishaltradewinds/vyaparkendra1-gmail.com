import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import authRoutes from "./routes/auth.js";
import walletRoutes from "./routes/wallet.js";
import dashboardRoutes from "./routes/dashboard.js";

dotenv.config();
const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI)
  .then(()=>console.log("Mongo Connected"))
  .catch(err=>console.log(err));

app.use("/api/auth", authRoutes);
app.use("/api/wallet", walletRoutes);
app.use("/api/dashboard", dashboardRoutes);

app.get("/api/health",(req,res)=>{
  res.json({status:"VyaparKendra Enterprise Backend Running"});
});

app.listen(process.env.PORT || 5000, ()=>{
  console.log("Server Running");
});