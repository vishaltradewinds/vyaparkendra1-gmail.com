import { useEffect, useState } from "react";
import axios from "axios";

export default function App(){

  const [data,setData] = useState({});

  useEffect(()=>{
    axios.get("/api/dashboard")
      .then(res=>setData(res.data))
      .catch(()=>{});
  },[]);

  return(
    <div style={{padding:40}}>
      <h1>VyaparKendra Enterprise Dashboard</h1>
      <p>Gross Revenue: ₹ {data?.financial?.grossRevenue}</p>
      <p>Wallet Liability: ₹ {data?.financial?.walletLiability}</p>
    </div>
  );
}